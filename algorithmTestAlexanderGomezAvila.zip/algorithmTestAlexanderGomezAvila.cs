﻿using System;
using System.Collections.Generic;

class programa
{
    static int size;
    static int[] DataBase;
    static int consult;
    static int[] DataConsult;
    static bool exit;
    static void Main()
    {
        while (!exit)
        {
            Inputs();
            Rendering();
            Console.WriteLine("ingresa cualquier caracter para salir del Test o preciona enter para repetir");
            string value = Console.ReadLine();
            if(value != "")
            {
                exit = true;
            }
        }
    }
    public static void Rendering()
    {
        for(int i = 0; i < consult; i++)
        {
            int firstNumber = 0;
            int secondNumber = 0;
            bool existFirst = false;
            bool existSecond = false;
            for (int e = 0; e < size; e++)
            {
                if(DataConsult[i] > DataBase[e])
                {
                    existFirst = true;
                    firstNumber = DataBase[e];
                }
            }
            for(int e = size -1; e > 0; e--)
            {
                if(DataConsult[i] < DataBase[e])
                {
                    existSecond = true;
                    secondNumber = DataBase[e];
                }
            }
            string writeFirstNumber = "";
            string writeSecondNumber = "";
            if (existFirst)
            {
                writeFirstNumber = firstNumber.ToString();
            } else
            {
                writeFirstNumber = "X";
            }
            if (existSecond)
            {
                writeSecondNumber = secondNumber.ToString();
            }
            else
            {
                writeSecondNumber = "X";
            }
            if(i == 0)
            {
                Console.WriteLine("Este es el listado de consultas realizadas:");
            }
            Console.WriteLine(writeFirstNumber + " " + writeSecondNumber);
        }
    }
    public static void Inputs()
    {
    	Console.WriteLine("Ingrese el tamaño de la lista");
        string InputSize = Console.ReadLine();
        size = Int32.Parse(InputSize);
        Console.WriteLine("Ingrese el Listado de numeros enteros separandolos con un espasio");
        string InputList = Console.ReadLine();
        DataBase = Converter(InputList, true);
        Console.WriteLine("Ingrese el numero de consultas");
        string InputConsult = Console.ReadLine();
        consult = Int32.Parse(InputConsult);
        Console.WriteLine("Ingrese el Listado de numeros a consultar separandolos con un espasio");
        string InputDataConsult = Console.ReadLine();
        DataConsult = Converter(InputDataConsult, false);
    }
    public static int[] Converter(string rawData, bool sortActive)
    {
        List<int> ListData = new List<int>();
        string[] DataRaw = rawData.Split(' ');
        foreach (string st in DataRaw)
        {
            ListData.Add(Int32.Parse(st));
        }
        if(sortActive)
        ListData.Sort();
        return ListData.ToArray();
    }
}
